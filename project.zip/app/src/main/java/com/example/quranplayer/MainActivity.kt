package com.example.quranplayer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var controller: MediaController? = null
    private val pending = ArrayList<(MediaController) -> Unit>()
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(2)

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) js("window.__native&&__native.ended()")
        }
        override fun onPlayerError(error: PlaybackException) {
            js("window.__native&&__native.error()")
        }
    }

    private val songsDir: File by lazy {
        val base = getExternalFilesDir(null) ?: filesDir
        File(base, "surahs").apply { mkdirs() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = WebView(this)
        web.setBackgroundColor(0xFF0A1D18.toInt())
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        PlaybackService.onSkip = { dir ->
            runOnUiThread { js("window.__nativeSkip&&__nativeSkip($dir)") }
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                pending.forEach { it(c) }
                pending.clear()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(this))

        handler.post(ticker)
    }

    private fun js(code: String) {
        web.evaluateJavascript(code, null)
    }

    private fun tick() {
        val c = controller ?: return
        val state = c.playbackState
        val playing = c.playWhenReady && state != Player.STATE_ENDED && state != Player.STATE_IDLE
        val dur = if (c.duration == C.TIME_UNSET) 0L else c.duration
        js("window.__native&&__native.tick($playing,${c.currentPosition},$dur)")
    }

    private fun withController(block: (MediaController) -> Unit) {
        runOnUiThread {
            val c = controller
            if (c != null) block(c) else pending.add(block)
        }
    }

    private fun fileFor(key: String) = File(songsDir, Uri.encode(key) + ".mp3")

    inner class Bridge {

        @JavascriptInterface
        fun setSource(url: String, title: String, artist: String) = withController { c ->
            c.pause()
            val item = MediaItem.Builder()
                .setUri(url)
                .setMediaMetadata(
                    MediaMetadata.Builder().setTitle(title).setArtist(artist).build()
                )
                .build()
            c.setMediaItem(item)
            c.prepare()
        }

        @JavascriptInterface fun play() = withController { it.play() }
        @JavascriptInterface fun pause() = withController { it.pause() }
        @JavascriptInterface fun stop() = withController { it.stop(); it.clearMediaItems() }
        @JavascriptInterface fun seekTo(ms: Double) = withController { it.seekTo(ms.toLong()) }

        @JavascriptInterface
        fun listKeys(): String {
            val arr = JSONArray()
            songsDir.listFiles()?.forEach { f ->
                if (f.isFile && f.name.endsWith(".mp3") && f.length() > 0) {
                    arr.put(Uri.decode(f.name.removeSuffix(".mp3")))
                }
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun fileUri(key: String): String {
            val f = fileFor(key)
            return if (f.isFile && f.length() > 0) Uri.fromFile(f).toString() else ""
        }

        @JavascriptInterface
        fun deleteKey(key: String) {
            fileFor(key).delete()
        }

        @JavascriptInterface
        fun download(key: String, url: String) {
            io.execute {
                val target = fileFor(key)
                val part = File(target.path + ".part")
                val k = JSONObject.quote(key)
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 20000
                    conn.readTimeout = 30000
                    conn.instanceFollowRedirects = true
                    if (conn.responseCode !in 200..299) throw RuntimeException("HTTP " + conn.responseCode)
                    val total = conn.contentLengthLong
                    var got = 0L
                    var lastPct = -1
                    conn.inputStream.use { input ->
                        part.outputStream().use { out ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                got += n
                                val pct = if (total > 0) (got * 100 / total).toInt() else -1
                                if (pct != lastPct) {
                                    lastPct = pct
                                    runOnUiThread { js("window.__nativeDl&&__nativeDl.progress($k,$pct)") }
                                }
                            }
                        }
                    }
                    target.delete()
                    if (!part.renameTo(target)) throw RuntimeException("rename failed")
                    runOnUiThread { js("window.__nativeDl&&__nativeDl.done($k,true,\"\")") }
                } catch (e: Exception) {
                    part.delete()
                    val msg = JSONObject.quote(e.message ?: "error")
                    runOnUiThread { js("window.__nativeDl&&__nativeDl.done($k,false,$msg)") }
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // نخلي الصوت شغال في الخلفية بدل ما نقفل التطبيق
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        PlaybackService.onSkip = null
        controller?.release()
        controller = null
        io.shutdown()
        super.onDestroy()
    }
}
